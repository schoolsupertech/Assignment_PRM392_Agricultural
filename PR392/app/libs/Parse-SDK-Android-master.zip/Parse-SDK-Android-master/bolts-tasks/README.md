## bolts-tasks
Fork of [Bolts-Android](https://github.com/BoltsFramework/Bolts-Android), since it is no longer
really maintained/supported. Moving it here gives us the control over the dependency and allow us to shift
to other async solutions, such as Kotlin coroutines, long-term.
